# PRMS — Patient Referral Management System

Mobile-first web deployment. No Docker. MySQL installed directly. No React
Native mobile app — every function is available through the responsive
web admin, which now works as a first-class mobile experience (off-canvas
navigation drawer, card-based lists instead of horizontally-scrolling
tables, single-column forms on phones scaling to multi-column on tablet+).

This package was extracted from `PRMS-configured.zip`, verified end-to-end
against a **real local MySQL 8 install (no Docker)**, and had several bugs
fixed along the way (see "Bugs fixed" below).

---

## 1. Security note — rotate your secrets

Your uploaded `.env` contained live credentials (Gmail SMTP app password,
Africa's Talking API key, Firebase service-account private key, DB
encryption key). Those have now passed through this chat, so:

- **Rotate** the Gmail app password and Africa's Talking API key.
- Re-generate the DB `ENCRYPTION_KEY` / `HASH_SALT` if this is heading to
  a real production environment (test data only so far — fine to keep
  for local dev).
- JWT signing keys have been **removed** from this package. Run
  `bash prms-backend/scripts/generate-keys.sh` to generate a fresh pair
  the app will use going forward.
- `.env` files were stripped from this package. Copy your real values
  into `prms-backend/.env` and `prms-web-admin/.env` from the
  `.env.example` templates.

## 2. Prerequisites (Windows, Mac, or Linux — no Docker)

- Node.js 20+
- MySQL 8.0 **installed directly** (MySQL Installer on Windows, or
  `brew install mysql` / `apt install mysql-server`)
- Redis — on Windows use "Redis for Windows" or WSL; Mac/Linux:
  `brew install redis` / `apt install redis-server`

## 3. Database setup (no Docker)

```sql
CREATE DATABASE prms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'prms_user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'your_password_here';
GRANT ALL PRIVILEGES ON prms_db.* TO 'prms_user'@'localhost';
FLUSH PRIVILEGES;
SET GLOBAL log_bin_trust_function_creators = 1;  -- needed once, for the migration that creates triggers
```

> We deliberately create the user with `mysql_native_password`, not
> MySQL 8's default `caching_sha2_password` — the `mysql2` Node driver
> has known compatibility issues with the latter (this matches the fix
> from your earlier Windows deployment work).

`log_bin_trust_function_creators` must be enabled (or the DB user needs
`SUPER`) because migration `011_create_stored_procedures.sql` creates a
trigger, and MySQL requires this when binary logging is on.

## 4. Backend

```bash
cd prms-backend
cp .env.example .env        # then fill in your real DB/Redis/SMTP/etc values
npm install
bash scripts/generate-keys.sh
npm run migrate
npm run seed
npm run dev                 # http://localhost:3000
```

Health check: `GET http://localhost:3000/health`

Seeded login (System Admin): `admin` / `PaschalMe123!` (change immediately
in a real deployment — this is dev-seed data only).

## 5. Web Admin (mobile-first)

```bash
cd prms-web-admin
cp .env.example .env         # VITE_API_BASE_URL=http://localhost:3000/api/v1
npm install
npm run dev                  # http://localhost:5173
```

Open it on your phone (same Wi-Fi, `http://<your-pc-lan-ip>:5173`) or
just shrink your browser — the whole app reflows: the sidebar becomes a
slide-out drawer opened from the hamburger icon, and every list (referrals,
patients, hospitals, staff, audit logs) renders as touch-friendly cards
instead of a table.

For a production build: `npm run build` → deploy the `dist/` folder to
any static host / IIS / nginx.

---

## Bugs found and fixed during this pass

**Backend / MySQL correctness:**
1. `011_create_stored_procedures.sql` — `LEAVE sp_transition_referral_status;`
   is invalid MySQL (you can't `LEAVE` a procedure name); the outer block
   is now labelled `proc_body: BEGIN ... END proc_body;` and every `LEAVE`
   points at that label.
2. **mysql2 v3 `execute()` + `LIMIT ? OFFSET ?` → "Incorrect arguments to
   mysqld_stmt_execute"** — a known mysql2 prepared-statement limitation.
   Fixed across 6 repositories (`hospitals`, `patients`, `referrals`,
   `users`, `audit`, `chat`, `notifications`) by inlining the
   already-validated integer limit/offset directly into the SQL string
   (`LIMIT ${Number(limit)} OFFSET ${Number(offset)}`) instead of binding
   them as prepared-statement parameters. These values are always parsed
   through Zod (`z.coerce.number().int()`, clamped to a max page size)
   before reaching the query, so this is safe — never raw user input.

**Web admin — mobile-first:**
3. The sidebar's off-canvas CSS (`transform: translateX(-100%)` /
   `&.open`) existed but nothing ever toggled it below 1024px — there was
   no hamburger button and no state managing an `open` class, so on any
   phone or narrow tablet the entire navigation was simply invisible with
   no way to open it. Added a `LayoutProvider` context, a hamburger button
   in the TopBar, a close button in the drawer, a backdrop overlay, and
   auto-close on route change.
4. The shared `DataTable` (used by Referrals, Patients, Hospitals, Staff,
   and Audit Logs) rendered a fixed HTML `<table>` at every width, forcing
   horizontal scrolling on phones. It now renders each row as a stacked
   card below 768px, with the first column as the card title and the rest
   as label/value pairs — no per-page changes needed since every list page
   uses the same shared component.

Everything else — patient/referral forms (`Grid xs={12} sm={6}`), the
KPI grid, the chat screen (single-column flex layout) — was already built
mobile-first and needed no changes.

## Round 2 — search suggestions + downloadable reports (this update)

**1. Patient search returned nothing for partial names.**
Patient PII (name, national ID, phone) is stored AES-256-GCM encrypted,
with an HMAC "blind index" for lookups — but blind indexes only support
*exact* matches, so typing "Odh" for "Odhiambo..." matched nothing, in
both the referral form's patient-search modal and the Patients list page
search box. Fixed by decrypting a bounded, already-permission-scoped
candidate set (capped at 1000 rows, same hospital-isolation rules as
everywhere else) and filtering in memory. This adds no new plaintext to
the database and only touches records the requesting user could already
view unmasked — it's the same decrypt operation the patient list page
already performed, just applied before rendering instead of after.
This approach is appropriate at hospital-department scale; a facility
with tens of thousands of patients would eventually want a dedicated
searchable-encryption index (e.g. per-substring blind index) instead of
scanning candidates in memory.

**2. Patient search required clicking a "Search" button.**
`PatientQuickSearch` now searches live as you type (300ms debounce, same
pattern as the destination hospital field) instead of requiring an
explicit click — real typeahead suggestions, minimum 2 characters.

**3. Hospital destination search** was already correctly implemented
(plaintext data, real `LIKE` query, live Autocomplete) — verified working,
no changes needed.

**4. PDF report export was completely broken (500 error on every attempt).**
The previous implementation hand-assembled raw PDF bytes (manually writing
the xref table and byte offsets) and had an off-by-one indexing bug
(`objects[6]`, which was always `undefined` since the array only had
indices 0–5) — every single export crashed with "Cannot read properties
of undefined (reading 'length')". Replaced with `pdfkit`, a well-tested
library: reports now generate correctly, paginate automatically across
multiple pages, and handle special characters properly. Verified all
three report types (County, Referral Trends, Facility Performance)
produce valid, multi-page PDFs with proper headers/footers.

## Round 3 — visual identity borrowed from MedicentreV3 (this update)

You asked for the look to borrow from MedicentreV3 (the legacy hospital
system whose referral PDF you shared) but expressed as modern. Design plan:

**What MedicentreV3 actually does:** a teal medical-cross logo, a
Bootstrap-3-era teal→blue gradient header (`#4ca1af → #2980b9`), Lato/
Helvetica type, flat Bootstrap primary blue (`#337ab7`) for actions.

**What carried over, reinterpreted:**
- PRMS already used a deep teal (`#0B6B5D`) as its brand color, so the
  lineage was already there — this pass makes the connection deliberate
  instead of coincidental.
- Added a **brand gradient** (`teal-600 → teal-400 → info-500`, 135°) —
  the same teal→blue idea as MedicentreV3's header, but deeper and
  richer instead of the flat pastel original. Defined once in
  `theme/design-tokens.ts` as `gradients.brand`, used in exactly two
  places: the sidebar's header band and the login screen's brand panel.
  Everywhere else stays quiet — buttons, cards, and status badges are
  unchanged flat colors, so the gradient reads as a signature accent
  rather than a wash over the whole product.
- Replaced the 🏥 emoji placeholder with a real vector mark
  (`shared/components/ui/BrandMark.tsx`) — a rounded cross on a gradient
  square, the same medical-cross idea as MedicentreV3's raster icon, now
  a proper scalable SVG.
- Redesigned the login screen as a split panel: the gradient brand panel
  on the left (with a large ghosted version of the mark for texture) and
  the form on the right — a common modern SaaS pattern, and a more
  confident front door than the previous plain centered card. Collapses
  to a compact gradient band above the form on mobile, so the branding
  frames the task instead of competing with it on a small screen.
- Kept the existing Outfit/Inter typography, the amber accent, and the
  "triage left-border" status system exactly as they were — those were
  already deliberate, modern choices and didn't need to change to
  reference MedicentreV3.

## What's intentionally not included

`prms-mobile` (React Native) was excluded per your request. Every
capability it would have offered — referral creation/tracking, patient
lookup, chat, push-style notifications, reports — is present in the
mobile-first web admin instead.
