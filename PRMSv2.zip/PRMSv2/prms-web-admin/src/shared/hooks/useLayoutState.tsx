import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

interface ILayoutState {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  closeSidebar: () => void;
}

const LayoutContext = createContext<ILayoutState | undefined>(undefined);

/**
 * Provides mobile-first navigation drawer state.
 * On desktop (>=1024px) the sidebar is always visible via CSS; this state
 * only matters below that breakpoint, where the sidebar becomes an
 * off-canvas drawer toggled from the TopBar hamburger button.
 */
export const LayoutProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  // Auto-close the drawer whenever the route changes (mobile UX expectation).
  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  const toggleSidebar = useCallback(() => setSidebarOpen((v) => !v), []);
  const closeSidebar = useCallback(() => setSidebarOpen(false), []);

  return (
    <LayoutContext.Provider value={{ sidebarOpen, toggleSidebar, closeSidebar }}>
      {children}
    </LayoutContext.Provider>
  );
};

export const useLayoutState = (): ILayoutState => {
  const ctx = useContext(LayoutContext);
  if (!ctx) {
    throw new Error('useLayoutState must be used within a LayoutProvider');
  }
  return ctx;
};
