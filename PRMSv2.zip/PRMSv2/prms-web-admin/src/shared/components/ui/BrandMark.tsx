import React from 'react';
import { colors } from '@/theme/design-tokens';

interface BrandMarkProps {
  size?: number;
  /** Renders a flat white mark for use on top of the gradient itself (e.g. inside the gradient panel). */
  onGradient?: boolean;
}

/**
 * PRMS brand mark — a rounded cross inside a soft square.
 *
 * A deliberate nod to MedicentreV3's teal medical-cross logo (the legacy
 * system this product replaces), reinterpreted as a flat vector mark with
 * the brand gradient instead of a raster icon on a flat teal fill — same
 * lineage, modern execution.
 */
export const BrandMark: React.FC<BrandMarkProps> = ({ size = 40, onGradient = false }) => {
  const gradientId = 'prms-brand-mark-gradient';

  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={colors.teal[600]} />
          <stop offset="55%" stopColor={colors.teal[400]} />
          <stop offset="100%" stopColor={colors.info[500]} />
        </linearGradient>
      </defs>
      <rect
        width="40"
        height="40"
        rx="11"
        fill={onGradient ? 'rgba(255,255,255,0.16)' : `url(#${gradientId})`}
      />
      <path
        d="M18 11.5C18 10.6716 18.6716 10 19.5 10H20.5C21.3284 10 22 10.6716 22 11.5V18H28.5C29.3284 18 30 18.6716 30 19.5V20.5C30 21.3284 29.3284 22 28.5 22H22V28.5C22 29.3284 21.3284 30 20.5 30H19.5C18.6716 30 18 29.3284 18 28.5V22H11.5C10.6716 22 10 21.3284 10 20.5V19.5C10 18.6716 10.6716 18 11.5 18H18V11.5Z"
        fill="white"
      />
    </svg>
  );
};
