import { type ReactNode } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import Paper from '@mui/material/Paper';
import Skeleton from '@mui/material/Skeleton';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import useMediaQuery from '@mui/material/useMediaQuery';
import { EmptyState } from './EmptyState';

export interface Column<T> {
  key: keyof T | string;
  label: string;
  width?: string;
  align?: 'left' | 'center' | 'right';
  render?: (value: T[keyof T], row: T) => ReactNode;
  sortable?: boolean;
}

interface DataTableProps<T extends { id: number | string }> {
  columns: Column<T>[];
  data: T[];
  loading?: boolean;
  emptyTitle?: string;
  emptyBody?: string;
  onRowClick?: (row: T) => void;
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
  onSort?: (key: string) => void;
}

/**
 * Generic, typed data table used across Hospital List, Staff List,
 * Audit Log, and Facility Performance Report.
 * See PRMS_Design_System_Complete.md §7 (Table Design System).
 */
export function DataTable<T extends { id: number | string }>({
  columns, data, loading, emptyTitle, emptyBody,
  onRowClick, sortBy, sortDir, onSort,
}: DataTableProps<T>) {
  // Mobile-first: below tablet width, a wide table forces horizontal scrolling
  // and tiny touch targets. Render each row as a stacked card instead —
  // first column is the card's title, the rest are label/value pairs.
  const isMobile = useMediaQuery('(max-width:768px)');

  if (isMobile) {
    const [titleCol, ...detailCols] = columns;

    if (loading) {
      return (
        <Box display="flex" flexDirection="column" gap={1.5}>
          {Array.from({ length: 4 }).map((_, i) => (
            <Paper key={i} variant="outlined" sx={{ p: 2, borderRadius: 2.5 }}>
              <Skeleton variant="text" width="60%" height={28} />
              <Skeleton variant="text" width="90%" />
              <Skeleton variant="text" width="75%" />
            </Paper>
          ))}
        </Box>
      );
    }

    if (data.length === 0) {
      return (
        <Paper variant="outlined" sx={{ borderRadius: 2.5, py: 6 }}>
          <EmptyState
            title={emptyTitle ?? 'No records found'}
            body={emptyBody ?? 'There is nothing to show here yet.'}
          />
        </Paper>
      );
    }

    return (
      <Box display="flex" flexDirection="column" gap={1.5}>
        {data.map((row) => {
          const rowRec = row as Record<string, unknown>;
          const titleValue = rowRec[titleCol.key as string];
          return (
            <Paper
              key={row.id}
              variant="outlined"
              onClick={() => onRowClick?.(row)}
              sx={{
                p: 2,
                borderRadius: 2.5,
                cursor: onRowClick ? 'pointer' : 'default',
                display: 'flex',
                flexDirection: 'column',
                gap: 0.75,
              }}
            >
              <Typography fontWeight={600} fontSize="0.9375rem">
                {titleCol.render ? titleCol.render(titleValue as T[keyof T], row) : String(titleValue ?? '—')}
              </Typography>
              {detailCols.map((col) => {
                const value = rowRec[col.key as string];
                return (
                  <Box key={String(col.key)} display="flex" justifyContent="space-between" gap={2}>
                    <Typography variant="caption" color="text.secondary">{col.label}</Typography>
                    <Typography variant="body2" textAlign="right">
                      {col.render ? col.render(value as T[keyof T], row) : String(value ?? '—')}
                    </Typography>
                  </Box>
                );
              })}
            </Paper>
          );
        })}
      </Box>
    );
  }

  return (
    <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2.5 }}>
      <Table>
        <TableHead>
          <TableRow>
            {columns.map((col) => (
              <TableCell key={String(col.key)} align={col.align ?? 'left'} width={col.width}>
                {col.sortable ? (
                  <TableSortLabel
                    active={sortBy === col.key}
                    direction={sortBy === col.key ? sortDir : 'asc'}
                    onClick={() => onSort?.(String(col.key))}
                  >
                    {col.label}
                  </TableSortLabel>
                ) : (
                  col.label
                )}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {loading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <TableRow key={i}>
                {columns.map((col) => (
                  <TableCell key={String(col.key)}>
                    <Skeleton variant="text" width={`${50 + Math.random() * 40}%`} />
                  </TableCell>
                ))}
              </TableRow>
            ))
          ) : data.length === 0 ? (
            <TableRow>
              <TableCell colSpan={columns.length} sx={{ py: 6, border: 0 }}>
                <EmptyState
                  title={emptyTitle ?? 'No records found'}
                  body={emptyBody ?? 'There is nothing to show here yet.'}
                />
              </TableCell>
            </TableRow>
          ) : (
            data.map((row) => (
              <TableRow
                key={row.id}
                hover={!!onRowClick}
                onClick={() => onRowClick?.(row)}
                sx={{ cursor: onRowClick ? 'pointer' : 'default' }}
              >
                {columns.map((col) => {
                  const value = (row as Record<string, unknown>)[col.key as string];
                  return (
                    <TableCell key={String(col.key)} align={col.align ?? 'left'}>
                      {col.render ? col.render(value as T[keyof T], row) : String(value ?? '—')}
                    </TableCell>
                  );
                })}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
