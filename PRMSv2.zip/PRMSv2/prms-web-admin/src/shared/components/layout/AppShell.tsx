import React from 'react';
import { Outlet } from 'react-router-dom';
import Box from '@mui/material/Box';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { LayoutProvider, useLayoutState } from '@/shared/hooks/useLayoutState';

const AppShellInner: React.FC = () => {
  const { sidebarOpen, closeSidebar } = useLayoutState();

  return (
    <Box className="prms-app-shell">
      <Sidebar />
      {/* Backdrop: only rendered (and only intercepts clicks) when the mobile drawer is open */}
      {sidebarOpen && (
        <Box
          className="prms-sidebar-backdrop"
          onClick={closeSidebar}
          role="presentation"
          aria-hidden="true"
        />
      )}
      <Box className="prms-main" component="main">
        <TopBar />
        <Box className="prms-page">
          <a href="#main-content" className="skip-link">Skip to main content</a>
          <div id="main-content">
            <Outlet />
          </div>
        </Box>
      </Box>
    </Box>
  );
};

/** Root authenticated layout — sidebar + topbar + routed page content. Mobile-first: sidebar is an off-canvas drawer below 1024px. */
export const AppShell: React.FC = () => (
  <LayoutProvider>
    <AppShellInner />
  </LayoutProvider>
);
