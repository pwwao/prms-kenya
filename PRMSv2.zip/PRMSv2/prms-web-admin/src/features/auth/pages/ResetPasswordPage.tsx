import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useSearchParams } from 'react-router-dom';
import { z } from 'zod';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Link from '@mui/material/Link';
import { AuthLayout } from './AuthLayout';
import { FormField, Button } from '@/shared/components/ui';
import { authApi } from '../api/auth.api';
import { ROUTES } from '@/shared/constants/routes.constants';

// Mirrors the backend's newPasswordSchema (auth.validator.ts) so the user
// gets the same feedback client-side before the request round-trips.
const schema = z.object({
  newPassword: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Must contain at least one number')
    .regex(/[@$!%*?&]/, 'Must contain at least one special character (@$!%*?&)'),
  confirmPassword: z.string(),
}).refine((d) => d.newPassword === d.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
});

type FormValues = z.infer<typeof schema>;

const ResetPasswordPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const resetToken = searchParams.get('token') ?? '';
  const [succeeded, setSucceeded] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
  });

  const mutation = useMutation({
    mutationFn: (values: FormValues) =>
      authApi.resetPassword({ resetToken, ...values }),
    onSuccess: () => setSucceeded(true),
  });

  if (!resetToken) {
    return (
      <AuthLayout title="Invalid Reset Link">
        <Stack spacing={2.5} textAlign="center">
          <Typography variant="body2" color="text.secondary">
            This reset link is missing or malformed. Request a new one below.
          </Typography>
          <Link href={ROUTES.FORGOT_PASSWORD} variant="body2">Request a new link</Link>
        </Stack>
      </AuthLayout>
    );
  }

  if (succeeded) {
    return (
      <AuthLayout title="Password Reset">
        <Stack spacing={2.5} textAlign="center">
          <Typography variant="body2" color="text.secondary">
            Your password has been updated. You can now sign in with your new password.
          </Typography>
          <Link href={ROUTES.LOGIN} variant="body2">← Back to Login</Link>
        </Stack>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout title="Set a New Password" subtitle="Choose a strong password for your account.">
      <form onSubmit={handleSubmit((v) => mutation.mutate(v))} noValidate>
        <Stack spacing={2.5}>
          {mutation.isError && (
            <Typography variant="body2" color="error">
              This link may have expired or already been used. Request a new one below.
            </Typography>
          )}
          <FormField
            label="New Password"
            type="password"
            autoFocus
            error={errors.newPassword?.message}
            {...register('newPassword')}
          />
          <FormField
            label="Confirm New Password"
            type="password"
            error={errors.confirmPassword?.message}
            {...register('confirmPassword')}
          />
          <Button type="submit" variant="primary" size="large" loading={mutation.isPending} fullWidth>
            Reset Password
          </Button>
          <Link href={ROUTES.LOGIN} variant="body2" align="center" sx={{ display: 'block' }}>
            ← Back to Login
          </Link>
        </Stack>
      </form>
    </AuthLayout>
  );
};

export default ResetPasswordPage;
