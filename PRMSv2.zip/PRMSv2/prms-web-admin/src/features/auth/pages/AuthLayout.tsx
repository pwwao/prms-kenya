import React, { type ReactNode } from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import { BrandMark } from '@/shared/components/ui/BrandMark';
import { gradients } from '@/theme/design-tokens';

interface AuthLayoutProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
}

/**
 * Split-panel auth shell: a gradient brand panel (desktop) carrying the
 * product's identity, next to the form itself. On mobile the panel
 * collapses to a compact top band so the form stays the focus — the
 * branding is a frame around the task, not competition for it.
 */
export const AuthLayout: React.FC<AuthLayoutProps> = ({ title, subtitle, children }) => (
  <Box minHeight="100vh" display="flex" sx={{ bgcolor: 'background.default' }}>
    {/* Brand panel — full left column on desktop, hidden on mobile in favour of the compact band below */}
    <Box
      sx={{
        display: { xs: 'none', md: 'flex' },
        width: '42%',
        minWidth: 360,
        background: gradients.brand,
        color: '#fff',
        flexDirection: 'column',
        justifyContent: 'space-between',
        p: 6,
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Subtle oversized mark ghosted in the corner — texture, not noise */}
      <Box sx={{ position: 'absolute', right: -60, bottom: -60, opacity: 0.12, transform: 'rotate(-8deg)' }}>
        <BrandMark size={280} onGradient />
      </Box>

      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, position: 'relative' }}>
        <BrandMark size={40} />
        <Typography fontWeight={700} fontFamily="'Outfit', sans-serif" fontSize="1.125rem">
          PRMS Kenya
        </Typography>
      </Box>

      <Box sx={{ position: 'relative' }}>
        <Typography fontFamily="'Outfit', sans-serif" fontWeight={600} fontSize="1.75rem" lineHeight={1.25} mb={1.5}>
          Every referral, tracked from
          <br />
          dispatch to admission.
        </Typography>
        <Typography color="rgba(255,255,255,0.8)" fontSize="0.9375rem" maxWidth={340}>
          The national patient referral network connecting county hospitals
          and referral facilities across Kenya.
        </Typography>
      </Box>
    </Box>

    {/* Form column */}
    <Box flex={1} display="flex" flexDirection="column">
      {/* Compact brand band — mobile only */}
      <Box
        sx={{
          display: { xs: 'flex', md: 'none' },
          alignItems: 'center',
          gap: 1.25,
          px: 3,
          py: 2.5,
          background: gradients.brand,
          color: '#fff',
        }}
      >
        <BrandMark size={30} />
        <Typography fontWeight={700} fontFamily="'Outfit', sans-serif">PRMS Kenya</Typography>
      </Box>

      <Box flex={1} display="flex" alignItems="center" justifyContent="center" px={2} py={4}>
        <Paper
          variant="outlined"
          sx={{
            width: '100%',
            maxWidth: 420,
            p: { xs: 3, sm: 4 },
            borderRadius: 3,
            border: { md: 'none' },
            boxShadow: { xs: 'none', md: '0 1px 3px 0 rgba(28,43,58,0.08), 0 1px 2px -1px rgba(28,43,58,0.06)' },
          }}
        >
          <Box textAlign="center" mb={3}>
            <Typography variant="h4" mb={subtitle ? 0.5 : 0}>{title}</Typography>
            {subtitle && (
              <Typography variant="body2" color="text.secondary">{subtitle}</Typography>
            )}
          </Box>
          {children}
        </Paper>
      </Box>
    </Box>
  </Box>
);
