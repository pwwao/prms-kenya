import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import CircularProgress from '@mui/material/CircularProgress';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';
import { FormField, EmptyState } from '@/shared/components/ui';
import { useDebounce } from '@/shared/hooks/useDebounce';
import { usePatientSearch } from '../hooks/usePatients';
import type { Patient } from '@/types/patient.types';

interface PatientQuickSearchProps {
  open: boolean;
  onClose: () => void;
  onSelect: (patient: Patient) => void;
}

/**
 * Modal used to find an existing patient by name, National ID, or phone
 * number before creating a referral — mirrors the mobile PatientSearchScreen
 * flow. Live suggestions appear as you type (debounced), the same way the
 * destination hospital field works — no more explicit "Search" click needed.
 */
export const PatientQuickSearch: React.FC<PatientQuickSearchProps> = ({ open, onClose, onSelect }) => {
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebounce(query, 300);
  const trimmed = debouncedQuery.trim();

  const { data: results, isLoading, isFetched } = usePatientSearch(
    { q: trimmed || undefined },
    trimmed.length >= 2,
  );

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Find Patient</DialogTitle>
      <DialogContent>
        <Box mb={2} mt={0.5}>
          <FormField
            label="Name, National ID, or Phone"
            placeholder="Start typing a name, ID, or phone number…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  {isLoading ? <CircularProgress size={16} /> : <SearchIcon fontSize="small" />}
                </InputAdornment>
              ),
            }}
          />
        </Box>

        <Box mt={2}>
          {trimmed.length > 0 && trimmed.length < 2 && (
            <Box fontSize="0.8125rem" color="text.secondary">Keep typing — at least 2 characters.</Box>
          )}

          {isFetched && !isLoading && trimmed.length >= 2 && (results?.length ?? 0) === 0 && (
            <EmptyState
              title="No matching patient"
              body="Try a different spelling, national ID, or phone number, or register this patient as new."
            />
          )}

          {(results?.length ?? 0) > 0 && (
            <List>
              {results!.map((patient) => (
                <ListItemButton key={patient.id} onClick={() => onSelect(patient)}>
                  <ListItemText
                    primary={patient.fullName}
                    secondary={`${patient.gender} · ${patient.county}${patient.nationalId ? ` · ID ${patient.nationalId}` : ''}`}
                  />
                </ListItemButton>
              ))}
            </List>
          )}
        </Box>
      </DialogContent>
    </Dialog>
  );
};
