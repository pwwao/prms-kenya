import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import MenuItem from '@mui/material/MenuItem';
import { FormField, Button } from '@/shared/components/ui';
import type { CreateHospitalRequest, FacilityLevel } from '@/types/hospital.types';

const facilityLevels: FacilityLevel[] = ['Level 2', 'Level 3', 'Level 4', 'Level 5', 'Level 6'];

interface HospitalFormProps {
  submitting?: boolean;
  errors?: Record<string, string>;
  onSubmit: (values: CreateHospitalRequest) => void;
  onCancel?: () => void;
}

export const HospitalForm: React.FC<HospitalFormProps> = ({ submitting, errors = {}, onSubmit, onCancel }) => {
  const [values, setValues] = useState<CreateHospitalRequest>({
    mohCode: '',
    name: '',
    facilityLevel: 'Level 4',
    county: '',
    subCounty: '',
    address: '',
    phone: '',
    email: '',
  });

  const set = <K extends keyof CreateHospitalRequest>(key: K, value: CreateHospitalRequest[K]) =>
    setValues((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(values);
  };

  return (
    <Box component="form" onSubmit={handleSubmit}>
      <Grid container spacing={2.5}>
        <Grid item xs={12} sm={6}>
          <FormField
            label="Hospital Name"
            required
            value={values.name}
            onChange={(e) => set('name', e.target.value)}
            error={errors.name}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormField
            label="MoH Code"
            required
            value={values.mohCode}
            onChange={(e) => set('mohCode', e.target.value)}
            error={errors.mohCode}
            helperText={errors.mohCode ?? 'Letters, digits, and hyphens only'}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormField
            select
            label="Facility Level"
            required
            value={values.facilityLevel}
            onChange={(e) => set('facilityLevel', e.target.value as FacilityLevel)}
            error={errors.facilityLevel}
          >
            {facilityLevels.map((lvl) => <MenuItem key={lvl} value={lvl}>{lvl}</MenuItem>)}
          </FormField>
        </Grid>
        <Grid item xs={12} sm={6} />
        <Grid item xs={12} sm={6}>
          <FormField
            label="County"
            required
            value={values.county}
            onChange={(e) => set('county', e.target.value)}
            error={errors.county}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormField
            label="Sub-County"
            required
            value={values.subCounty}
            onChange={(e) => set('subCounty', e.target.value)}
            error={errors.subCounty}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormField
            label="Address"
            value={values.address ?? ''}
            onChange={(e) => set('address', e.target.value)}
            error={errors.address}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormField
            label="Phone Number"
            value={values.phone ?? ''}
            onChange={(e) => set('phone', e.target.value)}
            error={errors.phone}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormField
            label="Email"
            type="email"
            value={values.email ?? ''}
            onChange={(e) => set('email', e.target.value)}
            error={errors.email}
          />
        </Grid>
      </Grid>

      <Box display="flex" gap={1.5} mt={3.5}>
        <Button type="submit" variant="primary" loading={submitting}>
          Register Hospital
        </Button>
        {onCancel && <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>}
      </Box>
    </Box>
  );
};
