import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Alert from '@mui/material/Alert';
import { PageHeader } from '@/shared/components/ui';
import { HospitalForm } from '../components/HospitalForm';
import { useCreateHospital } from '../hooks/useHospitals';
import { getApiErrorMessage, getApiErrorDetails } from '@/shared/api/api-client';
import { ROUTES } from '@/shared/constants/routes.constants';
import type { CreateHospitalRequest } from '@/types/hospital.types';

const HospitalRegistrationPage: React.FC = () => {
  const navigate = useNavigate();
  const mutation = useCreateHospital();

  const fieldErrors: Record<string, string> = {};
  if (mutation.isError) {
    for (const d of getApiErrorDetails(mutation.error)) fieldErrors[d.field] = d.message;
  }

  const handleSubmit = (values: CreateHospitalRequest) => {
    mutation.mutate(
      {
        ...values,
        address: values.address || null,
        phone: values.phone || null,
        email: values.email || null,
      },
      { onSuccess: (hospital) => navigate(ROUTES.HOSPITAL_DETAIL(hospital.id)) },
    );
  };

  return (
    <>
      <PageHeader
        title="Register Hospital"
        breadcrumbs={[{ label: 'Hospitals', href: ROUTES.HOSPITALS }, { label: 'Register Hospital' }]}
      />

      <Card variant="outlined" sx={{ maxWidth: 720 }}>
        <CardContent sx={{ p: 4 }}>
          {mutation.isError && (
            <Alert severity="error" sx={{ mb: 3 }}>{getApiErrorMessage(mutation.error)}</Alert>
          )}
          <HospitalForm
            submitting={mutation.isPending}
            errors={fieldErrors}
            onSubmit={handleSubmit}
            onCancel={() => navigate(ROUTES.HOSPITALS)}
          />
        </CardContent>
      </Card>
    </>
  );
};

export default HospitalRegistrationPage;
