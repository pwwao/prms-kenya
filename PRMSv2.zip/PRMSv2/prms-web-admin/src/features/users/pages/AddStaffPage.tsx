import React, { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Stack from '@mui/material/Stack';
import Alert from '@mui/material/Alert';
import Typography from '@mui/material/Typography';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';
import Box from '@mui/material/Box';
import Autocomplete from '@mui/material/Autocomplete';
import { PageHeader, FormField, Button } from '@/shared/components/ui';
import { useCreateStaff } from '../hooks/useUsers';
import { useHospitalsList } from '@/features/hospitals/hooks/useHospitals';
import { getApiErrorMessage } from '@/shared/api/api-client';
import { ROUTES } from '@/shared/constants/routes.constants';
import { useNavigate } from 'react-router-dom';
import { useAppSelector } from '@/shared/hooks/useAppDispatch';
import { usePermissions } from '@/shared/hooks/usePermissions';

// Hospital Admin can only create Clinician/Receptionist accounts for their
// own facility. System Admin can additionally create the Hospital Admin
// account for a facility — this is the only way to bootstrap staff access
// for a newly approved hospital, since it has no Hospital Admin yet.
const schema = z.object({
  role: z.enum(['Hospital Admin', 'Clinician', 'Receptionist']),
  fullName: z.string().min(2, 'Enter the staff member\'s full name'),
  username: z.string().min(4, 'Minimum 4 characters').regex(/^[a-zA-Z0-9_]+$/, 'Letters, numbers, underscores only'),
  email: z.string().email('Enter a valid email address').optional().or(z.literal('')),
  phoneNumber: z.string().regex(/^\+254\d{9}$/, 'Format: +254XXXXXXXXX').optional().or(z.literal('')).or(z.literal('+254')),
});

type FormValues = z.infer<typeof schema>;

function generateTemporaryPassword() {
  const charset = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*()-_=+';
  const randomValues = crypto.getRandomValues(new Uint32Array(16));
  return Array.from(randomValues, (value) => charset[value % charset.length]).join('');
}

const AddStaffPage: React.FC = () => {
  const navigate = useNavigate();
  const user = useAppSelector((state) => state.auth.user);
  const { isSystemAdmin } = usePermissions();
  const mutation = useCreateStaff();
  const {
    register, handleSubmit, control, formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { role: isSystemAdmin ? 'Hospital Admin' : 'Clinician', phoneNumber: '+254' },
  });

  // Only System Admin needs to pick a hospital — a Hospital Admin's own
  // hospitalId is fixed and comes straight from their session.
  const [selectedHospitalId, setSelectedHospitalId] = useState<number | null>(null);
  const [hospitalQuery, setHospitalQuery] = useState('');
  const { data: hospitalResults, isLoading: hospitalsLoading } = useHospitalsList({
    status: 'Approved',
    q: hospitalQuery || undefined,
    page: 1,
    limit: 20,
  });

  const ownHospitalId = user?.hospitalId ?? null;
  const missingOwnHospital = user?.role === 'Hospital Admin' && ownHospitalId === null;
  const hospitalId = isSystemAdmin ? selectedHospitalId : ownHospitalId;
  const missingHospitalSelection = isSystemAdmin && selectedHospitalId === null;

  return (
    <>
      <PageHeader
        title="Add Staff Member"
        breadcrumbs={[{ label: 'Staff', href: ROUTES.USERS }, { label: 'Add Staff Member' }]}
      />

      {missingOwnHospital && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Your account is not associated with a hospital. Please log out and log back in,
          or contact your System Administrator to fix your account.
        </Alert>
      )}

      <Card variant="outlined" sx={{ maxWidth: 560 }}>
        <CardContent sx={{ p: 4 }}>
          <form
            onSubmit={handleSubmit((v) => {
              if (missingOwnHospital || hospitalId === null) return; // extra safety guard
              mutation.mutate({
                ...v,
                email: v.email ? v.email : null,
                phoneNumber: v.phoneNumber && v.phoneNumber !== '+254' ? v.phoneNumber : null,
                hospitalId,
                password: generateTemporaryPassword(),
              });
            })}
            noValidate
          >
            <Stack spacing={3}>
              {mutation.isError && <Alert severity="error">{getApiErrorMessage(mutation.error)}</Alert>}

              {isSystemAdmin && (
                <Autocomplete
                  options={hospitalResults?.data ?? []}
                  getOptionLabel={(h) => h.name}
                  loading={hospitalsLoading}
                  onInputChange={(_, value) => setHospitalQuery(value)}
                  onChange={(_, value) => setSelectedHospitalId(value?.id ?? null)}
                  renderInput={(params) => (
                    <FormField
                      {...params}
                      label="Hospital"
                      required
                      error={missingHospitalSelection ? 'Select which hospital this account belongs to' : undefined}
                    />
                  )}
                />
              )}

              <Box>
                <Typography variant="subtitle2" mb={1}>Role</Typography>
                <Controller
                  name="role"
                  control={control}
                  render={({ field }) => (
                    <RadioGroup row {...field}>
                      {isSystemAdmin && (
                        <FormControlLabel value="Hospital Admin" control={<Radio />} label="Hospital Admin" />
                      )}
                      <FormControlLabel value="Clinician" control={<Radio />} label="Clinician" />
                      <FormControlLabel value="Receptionist" control={<Radio />} label="Receptionist" />
                    </RadioGroup>
                  )}
                />
              </Box>

              <FormField label="Full Name" required error={errors.fullName?.message} {...register('fullName')} />
              <FormField label="Username" required error={errors.username?.message} {...register('username')} />
              <FormField label="Email Address" type="email" error={errors.email?.message} {...register('email')} />
              <FormField label="Phone Number" error={errors.phoneNumber?.message} {...register('phoneNumber')} />

              <Alert severity="info" variant="outlined">
                A temporary password is generated automatically for the new account.
              </Alert>

              <Stack direction="row" spacing={1.5} justifyContent="flex-end">
                <Button variant="outline" onClick={() => navigate(ROUTES.USERS)}>Cancel</Button>
                <Button
                  type="submit"
                  variant="primary"
                  loading={mutation.isPending}
                  disabled={missingOwnHospital || missingHospitalSelection}
                >
                  Create Account
                </Button>
              </Stack>
            </Stack>
          </form>
        </CardContent>
      </Card>
    </>
  );
};

export default AddStaffPage;
