import React from 'react';
import { RouterProvider } from 'react-router-dom';
import { ToastProvider } from '@/shared/components/ui/Toast';
import { router } from './router';


const App: React.FC = () => (
  <ToastProvider>
    <RouterProvider router={router} />
  </ToastProvider>
);

export default App;
