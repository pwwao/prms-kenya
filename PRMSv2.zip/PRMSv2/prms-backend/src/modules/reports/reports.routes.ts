/**
 * Reports Routes
 * Architecture Contract §8.7 / OpenAPI v1.0 — Analytics endpoints.
 *
 * GET  /api/v1/reports/county
 * GET  /api/v1/reports/referral-trends
 * GET  /api/v1/reports/facility-performance
 * GET  /api/v1/reports/export-pdf          ← NEW: PDF export
 *
 * Uses stored procedures sp_get_county_report and sp_get_facility_performance
 * from PRMS_Database_Complete.sql where they exist; referral-trends uses a
 * direct query (no SP was defined for it).
 *
 * Response shapes match the web admin CountyReportRow, ReferralTrendRow, and
 * FacilityPerformanceRow types in src/types/report.types.ts exactly.
 */

import { Router } from 'express';
import type { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { authenticate } from '../../middleware/authenticate.middleware.js';
import { authorize, requirePermission } from '../../middleware/authorize.middleware.js';
import { validate } from '../../middleware/validate.middleware.js';
import { sendSuccess } from '../../shared/response.helper.js';
import { reportRateLimiter } from '../../middleware/rate-limit.middleware.js';
import { BaseRepository } from '../../shared/base.repository.js';
import type mysql from 'mysql2/promise';

// ─── Validation ───────────────────────────────────────────────────────────────

// Base object kept extendable (no .refine() here — ZodEffects has no .extend()).
const dateRangeShape = z.object({
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'startDate must be YYYY-MM-DD'),
  endDate:   z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'endDate must be YYYY-MM-DD'),
});

// Shared cross-field check, applied to each extended schema individually.
const withDateRangeCheck = <T extends z.ZodTypeAny>(schema: T) =>
  schema.refine(
    (d: any) => d.startDate <= d.endDate,
    { message: 'startDate must not be after endDate', path: ['startDate'] }
  );

const countyReportQuerySchema = withDateRangeCheck(
  dateRangeShape.extend({
    county: z.string().trim().optional(),
  })
);

const trendsQuerySchema = withDateRangeCheck(
  dateRangeShape.extend({
    groupBy: z.enum(['day', 'week']).default('day'),
  })
);

const facilityQuerySchema = withDateRangeCheck(
  dateRangeShape.extend({
    hospitalId: z.coerce.number().int().positive().optional(),
  })
);

// PDF export query schema — supports all three report types
const pdfExportQuerySchema = withDateRangeCheck(
  dateRangeShape.extend({
    reportType: z.enum(['county', 'referral-trends', 'facility-performance']).default('county'),
    groupBy:    z.enum(['day', 'week']).default('day'),
    hospitalId: z.coerce.number().int().positive().optional(),
    county:     z.string().trim().optional(),
  })
);

// ─── Thin repository for report queries ──────────────────────────────────────

class ReportsRepository extends BaseRepository {
  protected readonly moduleName = 'reports';

  async getCountyReport(
    fromDate: string,
    toDate: string,
  ): Promise<mysql.RowDataPacket[]> {
    return this.query<mysql.RowDataPacket>(
      `CALL sp_get_county_report(?, ?)`,
      [fromDate, toDate],
    );
  }

  async getReferralTrends(
    fromDate: string,
    toDate: string,
    groupBy: 'day' | 'week',
  ): Promise<mysql.RowDataPacket[]> {
    const dateTrunc =
      groupBy === 'week'
        ? `DATE_FORMAT(DATE_SUB(r.created_at, INTERVAL WEEKDAY(r.created_at) DAY), '%Y-%m-%d')`
        : `DATE_FORMAT(r.created_at, '%Y-%m-%d')`;

    return this.query<mysql.RowDataPacket>(
      `SELECT
         ${dateTrunc}                                                      AS period,
         COUNT(*)                                                           AS total,
         SUM(CASE WHEN r.urgency_level = 'Urgent'   THEN 1 ELSE 0 END)   AS urgent,
         SUM(CASE WHEN r.urgency_level = 'Emergent' THEN 1 ELSE 0 END)   AS emergent,
         SUM(CASE WHEN r.urgency_level = 'Routine'  THEN 1 ELSE 0 END)   AS routine
       FROM referrals r
       WHERE r.created_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY)
       GROUP BY period
       ORDER BY period ASC`,
      [fromDate, toDate],
    );
  }

  async getFacilityPerformance(
    fromDate: string,
    toDate: string,
    hospitalId: number | null,
  ): Promise<mysql.RowDataPacket[]> {
    return this.query<mysql.RowDataPacket>(
      `CALL sp_get_facility_performance(?, ?, ?)`,
      [hospitalId, fromDate, toDate],
    );
  }
}

// ─── Dependencies ─────────────────────────────────────────────────────────────

const repo = new ReportsRepository();

// ─── Helpers — map DB snake_case to web camelCase ────────────────────────────

function mapCountyRow(row: mysql.RowDataPacket, filter?: string) {
  return {
    county:                   row.county as string,
    totalReferrals:           Number(row.total_referrals ?? 0),
    // SP doesn't return 'Accepted' count — derive from completed + in-flight
    accepted:                 Number(row.completed ?? 0),
    rejected:                 Number(row.rejected  ?? 0),
    completed:                Number(row.completed ?? 0),
    // 'pending' = total - completed - rejected
    pending:
      Number(row.total_referrals ?? 0) -
      Number(row.completed ?? 0) -
      Number(row.rejected  ?? 0),
    // SP returns minutes; web type expects hours
    averageResponseTimeHours:
      row.avg_completion_minutes != null
        ? Math.round((Number(row.avg_completion_minutes) / 60) * 10) / 10
        : 0,
  };
}

function mapTrendRow(row: mysql.RowDataPacket) {
  return {
    period:   row.period as string,
    total:    Number(row.total    ?? 0),
    urgent:   Number(row.urgent   ?? 0),
    emergent: Number(row.emergent ?? 0),
    routine:  Number(row.routine  ?? 0),
  };
}

function mapFacilityRow(row: mysql.RowDataPacket) {
  const sent     = Number(row.outgoing_referrals ?? 0);
  const received = Number(row.incoming_referrals ?? 0);
  const rejected = Number(row.rejections_incoming ?? 0);
  const completed = Number(row.completed_outgoing ?? 0);

  return {
    hospitalId:              Number(row.hospital_id),
    hospitalName:            row.hospital_name as string,
    facilityLevel:           row.facility_level as string,
    county:                  row.county as string,
    referralsSent:           sent,
    referralsReceived:       received,
    acceptanceRate:          received > 0 ? Math.round(((received - rejected) / received) * 1000) / 10 : 0,
    rejectionRate:           received > 0 ? Math.round((rejected / received) * 1000) / 10 : 0,
    averageResponseTimeHours:
      row.avg_accept_time_minutes != null
        ? Math.round((Number(row.avg_accept_time_minutes) / 60) * 10) / 10
        : 0,
    completionRate:          sent > 0 ? Math.round((completed / sent) * 1000) / 10 : 0,
  };
}

// ─── PDF generation helper ─────────────────────────────────────────────────
// Uses pdfkit (pure JS, no native deps) to generate a paginated table report.
// BUG FIX: the previous implementation hand-assembled raw PDF bytes (manual
// xref table + byte offsets) and had an off-by-one bug (referenced
// objects[6], which was always undefined since only indices 0-5 existed)
// that crashed every export with "Cannot read properties of undefined
// (reading 'length')". It also had no multi-page support and mishandled
// non-Latin1 characters. pdfkit fixes all three.

import PDFDocument from 'pdfkit';

type TableRow = Record<string, string | number>;

function buildPdfBuffer(
  title: string,
  subtitle: string,
  headers: string[],
  keys: string[],
  rows: TableRow[],
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 40, bufferPages: true });
    const chunks: Buffer[] = [];
    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const pageWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;
    const colWidth = pageWidth / headers.length;
    const rowHeight = 20;
    const bottomLimit = doc.page.height - doc.page.margins.bottom;

    doc.font('Helvetica-Bold').fontSize(16).text(title, { align: 'left' });
    doc.font('Helvetica').fontSize(9).fillColor('#555555').text(subtitle);
    doc.fillColor('#000000');
    doc.moveDown(0.5);
    doc.moveTo(doc.x, doc.y).lineTo(doc.page.width - doc.page.margins.right, doc.y).stroke();
    doc.moveDown(0.5);

    const drawHeaderRow = () => {
      const y = doc.y;
      doc.rect(doc.page.margins.left, y, pageWidth, rowHeight).fill('#d9d9d9');
      doc.fillColor('#000000').font('Helvetica-Bold').fontSize(8);
      headers.forEach((h, i) => {
        doc.text(h, doc.page.margins.left + i * colWidth + 4, y + 6, {
          width: colWidth - 8,
          lineBreak: false,
        });
      });
      doc.y = y + rowHeight;
    };

    drawHeaderRow();

    doc.font('Helvetica').fontSize(8);
    rows.forEach((row, ri) => {
      if (doc.y + rowHeight > bottomLimit) {
        doc.addPage();
        drawHeaderRow();
        doc.font('Helvetica').fontSize(8);
      }

      const y = doc.y;
      if (ri % 2 === 0) {
        doc.rect(doc.page.margins.left, y, pageWidth, rowHeight).fill('#f5f5f5');
      }
      doc.fillColor('#000000');
      keys.forEach((k, i) => {
        const val = String(row[k] ?? '—');
        doc.text(val, doc.page.margins.left + i * colWidth + 4, y + 6, {
          width: colWidth - 8,
          lineBreak: false,
          ellipsis: true,
        });
      });
      doc
        .moveTo(doc.page.margins.left, y + rowHeight)
        .lineTo(doc.page.width - doc.page.margins.right, y + rowHeight)
        .strokeColor('#cccccc')
        .stroke();
      doc.y = y + rowHeight;
    });

    if (rows.length === 0) {
      doc.moveDown(1).font('Helvetica-Oblique').fontSize(9).fillColor('#666666')
        .text('No data available for the selected date range.');
    }

    // Footer with generation timestamp on every page
    const pageRange = doc.bufferedPageRange();
    for (let i = pageRange.start; i < pageRange.start + pageRange.count; i++) {
      doc.switchToPage(i);
      doc
        .font('Helvetica')
        .fontSize(7)
        .fillColor('#888888')
        .text(
          `Generated by PRMS Kenya — ${new Date().toISOString().slice(0, 10)}`,
          doc.page.margins.left,
          doc.page.height - doc.page.margins.bottom + 10,
        );
    }

    doc.end();
  });
}

// ─── Router ───────────────────────────────────────────────────────────────────

const router = Router();

// All report endpoints require authentication + report:view permission.
// Rate limited to 10 req/min per the pre-built reportRateLimiter.
router.use(authenticate, requirePermission('report:view'), reportRateLimiter);

// GET /api/v1/reports/county
router.get(
  '/county',
  validate(countyReportQuerySchema, 'query'),
  async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { startDate, endDate, county } = req.query as z.infer<typeof countyReportQuerySchema>;
      const rows = await repo.getCountyReport(startDate, endDate);

      // Stored procedures return results in the first element of a CALL result
      const data = (Array.isArray(rows[0]) ? rows[0] : rows) as mysql.RowDataPacket[];
      let result = data.map(mapCountyRow);

      if (county) {
        result = result.filter((r) => r.county.toLowerCase() === county.toLowerCase());
      }

      sendSuccess(res, result, 'County report retrieved');
    } catch (err) { next(err); }
  },
);

// GET /api/v1/reports/referral-trends
router.get(
  '/referral-trends',
  validate(trendsQuerySchema, 'query'),
  async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const { startDate, endDate, groupBy } = req.query as z.infer<typeof trendsQuerySchema>;
      const rows = await repo.getReferralTrends(startDate, endDate, groupBy);
      sendSuccess(res, rows.map(mapTrendRow), 'Referral trends retrieved');
    } catch (err) { next(err); }
  },
);

// GET /api/v1/reports/facility-performance
router.get(
  '/facility-performance',
  authorize(['System Admin', 'Hospital Admin']),
  validate(facilityQuerySchema, 'query'),
  async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = req.user!;
      const { startDate, endDate, hospitalId } = req.query as z.infer<typeof facilityQuerySchema>;

      // Hospital Admin can only see their own facility's data
      const effectiveHospitalId =
        user.role === 'Hospital Admin' ? user.hospitalId : (hospitalId ?? null);

      const rows = await repo.getFacilityPerformance(startDate, endDate, effectiveHospitalId);
      const data = (Array.isArray(rows[0]) ? rows[0] : rows) as mysql.RowDataPacket[];

      sendSuccess(res, data.map(mapFacilityRow), 'Facility performance report retrieved');
    } catch (err) { next(err); }
  },
);

// GET /api/v1/reports/export-pdf
// ─────────────────────────────────────────────────────────────────────────────
// BUG FIX: This endpoint was missing entirely. Generates a PDF for any of the
// three report types and streams it as an attachment download.
// No external PDF library required — uses raw PDF syntax via Buffer.
// ─────────────────────────────────────────────────────────────────────────────
router.get(
  '/export-pdf',
  validate(pdfExportQuerySchema, 'query'),
  async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = req.user!;
      const {
        startDate,
        endDate,
        reportType,
        groupBy,
        hospitalId,
        county,
      } = req.query as z.infer<typeof pdfExportQuerySchema>;

      const dateRange = `${startDate} to ${endDate}`;
      let pdfBuffer: Buffer;

      if (reportType === 'county') {
        const rows = await repo.getCountyReport(startDate, endDate);
        const data = (Array.isArray(rows[0]) ? rows[0] : rows) as mysql.RowDataPacket[];
        let result = data.map(mapCountyRow);
        if (county) {
          result = result.filter((r) => r.county.toLowerCase() === county.toLowerCase());
        }
        pdfBuffer = await buildPdfBuffer(
          'County Referral Report',
          `Period: ${dateRange}  |  Generated by PRMS Kenya`,
          ['County', 'Total', 'Completed', 'Rejected', 'Pending', 'Avg Hrs'],
          ['county', 'totalReferrals', 'completed', 'rejected', 'pending', 'averageResponseTimeHours'],
          result as TableRow[],
        );

      } else if (reportType === 'referral-trends') {
        const rows = await repo.getReferralTrends(startDate, endDate, groupBy);
        const result = rows.map(mapTrendRow);
        pdfBuffer = await buildPdfBuffer(
          'Referral Trends Report',
          `Period: ${dateRange}  |  Grouped by: ${groupBy}  |  Generated by PRMS Kenya`,
          ['Period', 'Total', 'Routine', 'Urgent', 'Emergent'],
          ['period', 'total', 'routine', 'urgent', 'emergent'],
          result as TableRow[],
        );

      } else {
        // facility-performance — Hospital Admin scoped to own facility
        if (user.role !== 'System Admin' && user.role !== 'Hospital Admin') {
          res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Insufficient permissions' } });
          return;
        }
        const effectiveHospitalId =
          user.role === 'Hospital Admin' ? user.hospitalId : (hospitalId ?? null);
        const rows = await repo.getFacilityPerformance(startDate, endDate, effectiveHospitalId);
        const data = (Array.isArray(rows[0]) ? rows[0] : rows) as mysql.RowDataPacket[];
        const result = data.map(mapFacilityRow);
        pdfBuffer = await buildPdfBuffer(
          'Facility Performance Report',
          `Period: ${dateRange}  |  Generated by PRMS Kenya`,
          ['Hospital', 'Level', 'County', 'Sent', 'Received', 'Accept%', 'Complete%'],
          ['hospitalName', 'facilityLevel', 'county', 'referralsSent', 'referralsReceived', 'acceptanceRate', 'completionRate'],
          result as TableRow[],
        );
      }

      const filename = `prms-${reportType}-${startDate}-${endDate}.pdf`;
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Length', pdfBuffer.length);
      res.end(pdfBuffer);
    } catch (err) { next(err); }
  },
);

export { router as reportsRouter };
